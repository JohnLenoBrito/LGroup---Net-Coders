﻿// 3º JS

// Nesse JS vamos deixar todos os Clientes que cadastrados de um Array de Clientes (Lista)
var listClientes = [];

function AdicionarCliente(cliente) {
    listClientes.push(cliente);
}